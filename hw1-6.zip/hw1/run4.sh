#!/bin/bash

make
./convert double 3.1415
