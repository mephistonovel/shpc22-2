#pragma once

void matmul(const float *A, const float *B, float *C, int M, int N, int K,
            int num_threads);
