#pragma once

float vectordot_naive(float *A, float *B, int N);
float vectordot_fma(float *A, float *B, int N);
